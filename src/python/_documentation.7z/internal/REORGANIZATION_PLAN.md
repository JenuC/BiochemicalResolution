# Repository Reorganization and Git Commit Plan

## Directory Structure Changes

### New Structure:
```
mathematica/           # Original Mathematica files
  ├── notebooks/       # Original .nb files
  ├── data/           # Original data files (.npy, .mat)
  └── docs/           # PDF documentation

src/
  └── python/         # Our Python implementation
      ├── __init__.py
      ├── core.py
      ├── fisher_information.py
      ├── irf_functions.py
      ├── monte_carlo.py
      └── visualization.py

output/               # All generated outputs
  ├── plots/         # All .png, .pdf, .svg, .eps files
  ├── demos/         # Demo scripts and outputs
  └── validation/    # Validation reports and test outputs

notebooks/           # Converted Jupyter notebooks (keep as is)
data/               # Keep for runtime data
  ├── generated/
  └── reference/
```

## File Movements

### To mathematica/:
- InstrumentResponseFunction/*.nb → mathematica/notebooks/
- InstrumentResponseFunction/*.pdf → mathematica/docs/
- InstrumentResponseFunction/*.npy → mathematica/data/
- InstrumentResponseFunction/*.mat → mathematica/data/
- InstrumentResponseFunction/readme.txt → mathematica/

### To src/python/:
- src/*.py → src/python/

### To output/:
- All demo_*.png/pdf/svg/eps → output/plots/
- All test_*.png → output/plots/
- demo_*.py → output/demos/
- test_*.py → output/demos/
- TASK_*.md → output/validation/
- VALIDATION_REPORT.md → output/validation/
- validate_results.py → output/demos/

### Keep in root:
- README.md
- LICENSE
- requirements.txt
- setup.py
- PLOT_CUSTOMIZATION_GUIDE.md
- SPECIALIZED_PLOTS_DOCUMENTATION.md
- TROUBLESHOOTING.md
- USAGE_EXAMPLES.md

## Git Commit Plan (Based on Tasks)

### Commit 1: Initial project structure (Task 1)
**Message:** `feat: set up project structure and core interfaces`
**Files:**
- Create src/python/ directory structure
- Move src/__init__.py → src/python/__init__.py
- Move src/core.py → src/python/core.py
- requirements.txt
- setup.py
- README.md (initial version)

### Commit 2: Implement IRF functions (Task 2)
**Message:** `feat: implement IRF functions module with Dirac, Gaussian, and rectangular models`
**Files:**
- src/python/irf_functions.py

### Commit 3: Fisher information analysis (Task 3)
**Message:** `feat: develop Fisher information analysis module with Kollner-Wolfrum validation`
**Files:**
- src/python/fisher_information.py

### Commit 4: Monte Carlo simulations (Task 4)
**Message:** `feat: create Monte Carlo simulation module with curve fitting`
**Files:**
- src/python/monte_carlo.py

### Commit 5: Visualization module (Task 5)
**Message:** `feat: develop comprehensive visualization module with standardized plotting`
**Files:**
- src/python/visualization.py
- PLOT_CUSTOMIZATION_GUIDE.md
- SPECIALIZED_PLOTS_DOCUMENTATION.md

### Commit 6: Dirac IRF notebook (Task 6)
**Message:** `feat: convert Dirac IRF Fisher analysis notebook from Mathematica`
**Files:**
- notebooks/01_dirac_irf_fisher_analysis.ipynb
- notebooks/01_dirac_irf_fisher_analysis_validated.ipynb

### Commit 7: Gaussian IRF notebook (Task 7)
**Message:** `feat: convert Gaussian IRF Fisher analysis notebook from Mathematica`
**Files:**
- notebooks/02_gaussian_irf_fisher_analysis.ipynb
- notebooks/02_gaussian_irf_fisher_analysis_validated.ipynb

### Commit 8: Monte Carlo notebook (Task 8)
**Message:** `feat: enhance Monte Carlo simulations notebook with improved documentation`
**Files:**
- notebooks/03_monte_carlo_simulations.ipynb
- notebooks/03_monte_carlo_simulations_validated.ipynb
- notebooks/03_monte_carlo_simulations_base.json

### Commit 9: Visualization notebook (Task 9)
**Message:** `feat: create comprehensive visualization and analysis notebook`
**Files:**
- notebooks/04_visualization_and_analysis.ipynb
- notebooks/04_visualization_and_analysis_validated.ipynb

### Commit 10: Final validation and documentation (Task 10)
**Message:** `docs: add comprehensive documentation and validation reports`
**Files:**
- TROUBLESHOOTING.md
- USAGE_EXAMPLES.md
- output/validation/VALIDATION_REPORT.md
- output/validation/TASK_*.md
- output/demos/validate_results.py

### Commit 11: Organize original Mathematica files
**Message:** `chore: organize original Mathematica files into mathematica/ directory`
**Files:**
- Move all InstrumentResponseFunction/ contents to mathematica/

### Commit 12: Organize output files
**Message:** `chore: organize generated outputs into output/ directory`
**Files:**
- Move all demo and test outputs to output/

### Commit 13: Update documentation for new structure
**Message:** `docs: update documentation to reflect new directory structure`
**Files:**
- README.md (updated with new paths)
- setup.py (updated import paths if needed)

## Notes
- Each commit will be shown to you before execution
- You can modify the commit messages or groupings
- We'll preserve git history by using `git mv` where possible
- All commits will be prepared but not pushed automatically
