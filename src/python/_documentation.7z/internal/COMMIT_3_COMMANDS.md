# Commit 3: Fisher information analysis (Task 3)

## Git Commands:
```bash
# Move Fisher information module
git mv src/fisher_information.py src/python/fisher_information.py

# Commit
git commit -m "feat: develop Fisher information analysis module with Kollner-Wolfrum validation

- Implement calculate_fisher_matrix() for lifetime estimation precision
- Convert Mathematica mathematical expressions to NumPy operations
- Add kollner_wolfrum_reference() for Dirac IRF validation
- Create dirac_irf_analysis() for parameter exploration
- Implement gaussian_irf_analysis() with multiple sigma values
- Add progress tracking and memory-efficient computation

Tasks: 3.1, 3.2, 3.3
Requirements: 1.1, 1.2, 1.3"
```

## Files affected:
- src/fisher_information.py → src/python/fisher_information.py

## Verification:
After this commit:
```
src/python/
  ├── __init__.py
  ├── core.py
  ├── irf_functions.py
  └── fisher_information.py
```
