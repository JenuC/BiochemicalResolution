# Design Document

## Overview

This project converts Mathematica notebooks for Fisher information analysis of instrument response functions (IRF) to Python and enhances existing Python notebooks with comprehensive documentation. The system will provide a complete Python-based analysis pipeline for evaluating how IRFs affect measurement precision in fluorescence lifetime imaging microscopy (FLIM).

The conversion focuses on maintaining mathematical accuracy while improving code organization, documentation, and usability. The design emphasizes modularity, reproducibility, and educational value for researchers in the field.

## Architecture

### Project Structure
```
InstrumentResponseFunction/
├── notebooks/
│   ├── 01_dirac_irf_fisher_analysis.ipynb
│   ├── 02_gaussian_irf_fisher_analysis.ipynb
│   ├── 03_monte_carlo_simulations.ipynb
│   └── 04_visualization_and_analysis.ipynb
├── src/
│   ├── __init__.py
│   ├── fisher_information.py
│   ├── monte_carlo.py
│   ├── irf_functions.py
│   └── visualization.py
├── data/
│   ├── generated/
│   └── reference/
├── requirements.txt
├── setup.py
└── README.md
```

### Data Flow Architecture
```mermaid
graph TD
    A[Dirac IRF Fisher Analysis] --> D[Data Generation]
    B[Gaussian IRF Fisher Analysis] --> D
    C[Monte Carlo Simulations] --> D
    D --> E[Visualization & Analysis]
    
    F[Fisher Information Module] --> A
    F --> B
    G[IRF Functions Module] --> A
    G --> B
    G --> C
    H[Monte Carlo Module] --> C
    I[Visualization Module] --> E
```

## Components and Interfaces

### Core Modules

#### 1. Fisher Information Module (`fisher_information.py`)
**Purpose**: Implements Fisher information calculations for lifetime measurement precision analysis.

**Key Functions**:
- `calculate_fisher_matrix(tau, T, time_bins, irf_params)`: Computes Fisher information matrix
- `dirac_irf_analysis(tau_range, bin_range)`: Reproduces Kollner-Wolfrum validation
- `gaussian_irf_analysis(tau_range, bin_range, sigma_range)`: Gaussian IRF Fisher analysis
- `kollner_wolfrum_reference(tau, T, tn)`: Reference implementation for validation

**Interface**:
```python
def calculate_fisher_matrix(tau: float, T: float, time_bins: int, 
                          irf_type: str, irf_params: dict) -> np.ndarray:
    """
    Calculate Fisher information matrix for lifetime estimation.
    
    Parameters:
    - tau: Fluorescence lifetime (ns)
    - T: Repetition period (ns)  
    - time_bins: Number of time bins
    - irf_type: 'dirac', 'gaussian', or 'rectangular'
    - irf_params: IRF-specific parameters
    
    Returns:
    - Fisher information matrix
    """
```

#### 2. IRF Functions Module (`irf_functions.py`)
**Purpose**: Implements various instrument response function models.

**Key Functions**:
- `dirac_irf(t, t0)`: Dirac delta IRF
- `gaussian_irf(t, t0, sigma)`: Gaussian IRF model
- `rectangular_irf(t, t0, width)`: Rectangular IRF model
- `convolve_with_exponential(irf, tau, T, time_bins)`: Convolution operations

#### 3. Monte Carlo Module (`monte_carlo.py`)
**Purpose**: Implements Monte Carlo simulations for validation and extended analysis.

**Key Functions**:
- `generate_photon_data(pdf, num_photons, iterations)`: Generate synthetic photon data
- `fit_exponential_decay(data, initial_guess)`: Curve fitting routines
- `monte_carlo_analysis(tau_range, irf_params, iterations)`: Full MC analysis pipeline

#### 4. Visualization Module (`visualization.py`)
**Purpose**: Provides consistent plotting and visualization functions.

**Key Functions**:
- `plot_fisher_analysis(data, params)`: Standard Fisher information plots
- `plot_monte_carlo_results(data, params)`: MC simulation visualizations
- `plot_irf_comparison(irf_data)`: IRF shape comparisons
- `plot_separability_analysis(data)`: Separability and resolving power plots

## Data Models

### Parameter Configuration
```python
@dataclass
class AnalysisParameters:
    """Configuration for IRF analysis parameters."""
    repetition_period: float = 25.0  # ns
    lifetimes: np.ndarray = field(default_factory=lambda: np.arange(0.2, 15, 0.4))
    time_bins: np.ndarray = field(default_factory=lambda: 2**(np.arange(9)+2))
    irf_sigmas: np.ndarray = field(default_factory=lambda: np.array([0.01, 0.1, 0.25, 0.5, 1, 2]))
    num_photons: int = 75000
    iterations: int = 5000
```

### Results Data Structure
```python
@dataclass
class AnalysisResults:
    """Container for analysis results."""
    f_values: np.ndarray
    parameters: AnalysisParameters
    metadata: dict
    analysis_type: str
    
    def save(self, filepath: str) -> None:
        """Save results to file."""
        
    @classmethod
    def load(cls, filepath: str) -> 'AnalysisResults':
        """Load results from file."""
```

## Error Handling

### Input Validation
- Parameter range validation (positive lifetimes, reasonable IRF widths)
- Array dimension consistency checks
- Numerical stability warnings for extreme parameter combinations

### Computational Error Handling
- Graceful handling of curve fitting failures in Monte Carlo simulations
- NaN/infinity detection in Fisher information calculations
- Memory management for large parameter sweeps

### Error Recovery Strategies
```python
class IRFAnalysisError(Exception):
    """Base exception for IRF analysis errors."""
    pass

class ConvergenceError(IRFAnalysisError):
    """Raised when iterative algorithms fail to converge."""
    pass

class ValidationError(IRFAnalysisError):
    """Raised when results fail validation checks."""
    pass
```

## Testing Strategy

### Unit Testing
- Mathematical function accuracy tests against known analytical solutions
- IRF function normalization and convolution tests
- Parameter validation tests

### Integration Testing
- End-to-end notebook execution tests
- Cross-validation between Fisher information and Monte Carlo results
- Reproduction of literature benchmarks (Kollner-Wolfrum figures)

### Performance Testing
- Memory usage profiling for large parameter sweeps
- Execution time benchmarks for optimization
- Numerical precision validation

### Validation Testing
```python
def test_kollner_wolfrum_reproduction():
    """Test that Dirac IRF analysis reproduces Fig. 1 from Kollner & Wolfrum."""
    
def test_fisher_monte_carlo_consistency():
    """Verify Fisher information predictions match Monte Carlo results."""
    
def test_mathematical_accuracy():
    """Validate mathematical implementations against analytical solutions."""
```

## Implementation Considerations

### Mathematical Accuracy
- Use double precision floating point for all calculations
- Implement numerical stability checks for extreme parameter ranges
- Validate against published analytical results where available

### Performance Optimization
- Vectorized operations using NumPy for parameter sweeps
- Efficient convolution implementations using scipy.signal
- Optional parallel processing for Monte Carlo simulations

### Documentation Standards
- Comprehensive docstrings following NumPy documentation style
- Mathematical formulation references in notebook markdown
- Clear parameter descriptions with physical units
- Literature citations for all algorithms

### Reproducibility
- Fixed random seeds for Monte Carlo simulations
- Version pinning for all dependencies
- Detailed parameter logging and provenance tracking