# Commit 6: Dirac IRF notebook (Task 6)

## Git Commands:
```bash
# Stage Dirac IRF notebooks
git add notebooks/01_dirac_irf_fisher_analysis.ipynb
git add notebooks/01_dirac_irf_fisher_analysis_validated.ipynb

# Commit
git commit -m "feat: convert Dirac IRF Fisher analysis notebook from Mathematica

- Create comprehensive Jupyter notebook with mathematical explanations
- Add Fisher information theory background and literature references
- Implement step-by-step Fisher information calculations
- Add validation against Kollner-Wolfrum Figure 1
- Include detailed markdown explanations for each analysis step
- Add parameter sensitivity analysis and interpretation

Tasks: 6.1, 6.2, 6.3
Requirements: 1.1, 1.3, 2.1, 2.2"
```

## Files affected:
- notebooks/01_dirac_irf_fisher_analysis.ipynb (staged)
- notebooks/01_dirac_irf_fisher_analysis_validated.ipynb (staged)
