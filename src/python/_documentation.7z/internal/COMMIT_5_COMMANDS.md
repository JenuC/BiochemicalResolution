# Commit 5: Visualization module (Task 5)

## Git Commands:
```bash
# Move visualization module
git mv src/visualization.py src/python/visualization.py

# Add documentation files
git add PLOT_CUSTOMIZATION_GUIDE.md
git add SPECIALIZED_PLOTS_DOCUMENTATION.md

# Commit
git commit -m "feat: develop comprehensive visualization module with standardized plotting

- Implement plot_fisher_analysis() with consistent styling
- Create plot_monte_carlo_results() for simulation visualization
- Add plot_irf_comparison() for IRF shape analysis
- Implement plot_separability_analysis() for biochemical resolution
- Add plot_resolving_power() functions
- Create consistent color schemes and styling options
- Support figure export in multiple formats (PDF, PNG, SVG)
- Add plot annotation and labeling functions

Tasks: 5.1, 5.2, 5.3
Requirements: 2.1, 2.2, 4.1, 4.3"
```

## Files affected:
- src/visualization.py → src/python/visualization.py
- PLOT_CUSTOMIZATION_GUIDE.md (staged)
- SPECIALIZED_PLOTS_DOCUMENTATION.md (staged)

## Verification:
After this commit:
```
src/python/
  ├── __init__.py
  ├── core.py
  ├── irf_functions.py
  ├── fisher_information.py
  ├── monte_carlo.py
  └── visualization.py
```
