# Commit 11: Organize original Mathematica files

## Git Commands:
```bash
# Create mathematica directory structure
mkdir -p mathematica/notebooks
mkdir -p mathematica/data
mkdir -p mathematica/docs

# Move Mathematica notebooks
git mv InstrumentResponseFunction/DiracIRF_FisherInformation_V1.nb mathematica/notebooks/
git mv InstrumentResponseFunction/GaussianIRF_FisherInformation_V1.nb mathematica/notebooks/
git mv InstrumentResponseFunction/IRF_MCSimulations.ipynb mathematica/notebooks/
git mv InstrumentResponseFunction/IRF_Plots.ipynb mathematica/notebooks/

# Move documentation
git mv InstrumentResponseFunction/DiracIRF_FisherInformation_V1.pdf mathematica/docs/
git mv InstrumentResponseFunction/GaussianIRF_FisherInformation_V1.pdf mathematica/docs/

# Move data files
git mv InstrumentResponseFunction/F_dirac.npy mathematica/data/
git mv InstrumentResponseFunction/F_known.npy mathematica/data/
git mv InstrumentResponseFunction/F_knownsq.npy mathematica/data/
git mv InstrumentResponseFunction/F_unknown.npy mathematica/data/
git mv InstrumentResponseFunction/GaussianForMatlab.mat mathematica/data/

# Move readme
git mv InstrumentResponseFunction/readme.txt mathematica/

# Remove empty directory
rmdir InstrumentResponseFunction

# Commit
git commit -m "chore: organize original Mathematica files into mathematica/ directory

- Move Mathematica notebooks (.nb files) to mathematica/notebooks/
- Move PDF documentation to mathematica/docs/
- Move data files (.npy, .mat) to mathematica/data/
- Preserve original readme.txt
- Remove old InstrumentResponseFunction/ directory"
```

## Files affected:
- InstrumentResponseFunction/*.nb → mathematica/notebooks/
- InstrumentResponseFunction/*.pdf → mathematica/docs/
- InstrumentResponseFunction/*.npy → mathematica/data/
- InstrumentResponseFunction/*.mat → mathematica/data/
- InstrumentResponseFunction/readme.txt → mathematica/

## Verification:
After this commit:
```
mathematica/
  ├── notebooks/
  │   ├── DiracIRF_FisherInformation_V1.nb
  │   ├── GaussianIRF_FisherInformation_V1.nb
  │   ├── IRF_MCSimulations.ipynb
  │   └── IRF_Plots.ipynb
  ├── docs/
  │   ├── DiracIRF_FisherInformation_V1.pdf
  │   └── GaussianIRF_FisherInformation_V1.pdf
  ├── data/
  │   ├── F_dirac.npy
  │   ├── F_known.npy
  │   ├── F_knownsq.npy
  │   ├── F_unknown.npy
  │   └── GaussianForMatlab.mat
  └── readme.txt
```
