# Commit 2: Implement IRF functions (Task 2)

## Git Commands:
```bash
# Move IRF functions module
git mv src/irf_functions.py src/python/irf_functions.py

# Commit
git commit -m "feat: implement IRF functions module with Dirac, Gaussian, and rectangular models

- Implement dirac_irf() with proper normalization
- Add gaussian_irf() with configurable sigma parameter
- Create rectangular_irf() function with width parameter
- Implement convolve_with_exponential() for IRF-decay convolution
- Add efficient convolution using scipy.signal methods

Tasks: 2.1, 2.2
Requirements: 1.1, 1.4"
```

## Files affected:
- src/irf_functions.py → src/python/irf_functions.py

## Verification:
After this commit:
```
src/python/
  ├── __init__.py
  ├── core.py
  └── irf_functions.py
```
