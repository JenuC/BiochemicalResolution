# Commit 12: Organize output files

## Git Commands:
```bash
# Create output directory structure (if not exists)
mkdir -p output/plots
mkdir -p output/demos

# Move demo plot files
git mv demo_annotations.pdf output/plots/
git mv demo_annotations.png output/plots/
git mv demo_color_schemes.pdf output/plots/
git mv demo_color_schemes.png output/plots/
git mv demo_comparison_grid.png output/plots/
git mv demo_custom_colormap.png output/plots/
git mv demo_custom_colormap.svg output/plots/
git mv demo_fisher.png output/plots/
git mv demo_irf_comparison.eps output/plots/
git mv demo_irf_comparison.pdf output/plots/
git mv demo_irf_comparison.png output/plots/
git mv demo_irf_comparison.svg output/plots/
git mv demo_loss_analysis.png output/plots/
git mv demo_mc_comparison.png output/plots/
git mv demo_mc_precision.png output/plots/
git mv demo_nadh_separability.png output/plots/
git mv demo_resolving_power.png output/plots/

# Move test plot files
git mv test_3d_multi.png output/plots/
git mv test_3d_sigma_slice.png output/plots/
git mv test_3d_tau_slice.png output/plots/
git mv test_comparison_grid.png output/plots/
git mv test_fisher_plot.png output/plots/
git mv test_irf_comparison.png output/plots/
git mv test_loss_analysis.png output/plots/
git mv test_mc_comparison.png output/plots/
git mv test_mc_precision.png output/plots/
git mv test_resolving_power.png output/plots/
git mv test_separability.png output/plots/

# Move demo and test scripts
git mv demo_plot_customization.py output/demos/
git mv demo_specialized_analysis.py output/demos/
git mv demo_visualization.py output/demos/
git mv test_gaussian_notebook.py output/demos/
git mv test_irf_basic.py output/demos/
git mv test_plot_customization.py output/demos/
git mv test_specialized_plots.py output/demos/
git mv test_visualization_3d.py output/demos/
git mv test_visualization_core.py output/demos/

# Commit
git commit -m "chore: organize generated outputs into output/ directory

- Move all demo plots (PNG, PDF, SVG, EPS) to output/plots/
- Move all test plots to output/plots/
- Move demo scripts to output/demos/
- Move test scripts to output/demos/
- Clean up root directory for better organization"
```

## Files affected:
- demo_*.png/pdf/svg/eps → output/plots/
- test_*.png → output/plots/
- demo_*.py → output/demos/
- test_*.py → output/demos/

## Verification:
After this commit:
```
output/
  ├── plots/
  │   ├── demo_*.png/pdf/svg/eps
  │   └── test_*.png
  ├── demos/
  │   ├── demo_*.py
  │   ├── test_*.py
  │   └── validate_results.py
  └── validation/
      ├── TASK_*.md
      └── VALIDATION_REPORT.md
```
