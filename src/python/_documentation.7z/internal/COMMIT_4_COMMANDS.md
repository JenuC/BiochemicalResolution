# Commit 4: Monte Carlo simulations (Task 4)

## Git Commands:
```bash
# Move Monte Carlo module
git mv src/monte_carlo.py src/python/monte_carlo.py

# Commit
git commit -m "feat: create Monte Carlo simulation module with curve fitting

- Implement generate_photon_data() with Poisson statistics
- Create probability density function calculations for different IRFs
- Add fit_exponential_decay() with robust error handling
- Support known vs unknown IRF parameter fitting
- Implement monte_carlo_analysis() for full parameter sweep
- Add parallel processing for computational efficiency
- Include progress tracking and intermediate result saving

Tasks: 4.1, 4.2, 4.3
Requirements: 1.1, 1.4, 3.2, 3.3"
```

## Files affected:
- src/monte_carlo.py → src/python/monte_carlo.py

## Verification:
After this commit:
```
src/python/
  ├── __init__.py
  ├── core.py
  ├── irf_functions.py
  ├── fisher_information.py
  └── monte_carlo.py
```
