# Commit 13: Update documentation for new structure

## Git Commands:
```bash
# Update README.md with new directory structure
# (This will require manual editing or a script to update paths)

# Update setup.py if needed for new import paths
# (Check if packages=['src'] needs to be packages=['src.python'])

# Stage updated files
git add README.md
git add setup.py

# Commit
git commit -m "docs: update documentation to reflect new directory structure

- Update README.md with new directory paths
- Update import paths in setup.py for src/python/ structure
- Update references to mathematica/ and output/ directories
- Ensure all documentation reflects reorganized structure"
```

## Files affected:
- README.md (updated)
- setup.py (updated if needed)

## Manual Steps Required:
Before running this commit, you'll need to:

1. Update README.md to reference:
   - `src/python/` instead of `src/`
   - `mathematica/` for original files
   - `output/` for generated files

2. Update setup.py:
   - Change `packages=['src']` to `packages=['src.python']` or use `find_packages()`
   - Update any hardcoded paths

3. Check if any notebooks need path updates:
   - Import statements might need adjustment
   - Data file paths might need updating

## Example README.md changes:
```markdown
# Before:
from src.fisher_information import calculate_fisher_matrix

# After:
from src.python.fisher_information import calculate_fisher_matrix
```

## Example setup.py changes:
```python
# Before:
packages=['src']

# After:
packages=['src.python']
# or
packages=find_packages()
```
